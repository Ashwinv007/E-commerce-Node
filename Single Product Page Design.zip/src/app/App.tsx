import { ProductPage } from "./components/ProductPage";

export default function App() {
  return (
    <div className="size-full">
      <ProductPage />
    </div>
  );
}
