
  # Single Product Page Design

  This is a code bundle for Single Product Page Design. The original project is available at https://www.figma.com/design/OBKQDmYJFffnP5UaYhCHCu/Single-Product-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  